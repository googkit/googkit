# coding: utf-8

from .api import Coveralls

__all__ = ['api']